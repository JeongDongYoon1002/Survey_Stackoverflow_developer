import pandas as pd # package for high-performance, easy-to-use data structures and data analysis
import numpy as np # fundamental package for scientific computing with Python
import warnings
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
warnings.filterwarnings("ignore")
from sklearn.model_selection import train_test_split
from joblib import dump, load
import sys
# np.set_printoptions(threshold=sys.maxsize)
# pd.set_option('display.max_rows', 500)
# pd.set_option('display.max_columns', 500)
# pd.set_option('display.width', 1000)

# Print all rows and columns
pd.set_option('display.float_format', '{:.2f}'.format) # 항상 float 형식으로
data = pd.read_csv('/Users/leenamjun/ML-SuccessAsDeveloper/Project/Data/survey_results_public.csv')

# 의미가 있어보이는 칼럼 뽑
data__ = data[['Hobby', 'OpenSource', 'UndergradMajor', 'LanguageWorkedWith', 'JobSatisfaction',
               'YearsCoding', 'OperatingSystem', 'Gender', 'WakeTime', 'PlatformWorkedWith',
               'FrameworkWorkedWith', 'NumberMonitors', 'DatabaseWorkedWith', 'StackOverflowVisit', 'StackOverflowParticipate',
               'CheckInCode', 'ConvertedSalary']]

columns = data__.columns.values
print('Columns of data:')
print(columns)

# Number of Nan each column has
print('\nNumber of Nan each column has')
for col in columns:
    print('{} has {} nan'.format(col, data__[col].isnull().sum()))

# 하나라도 nan이 있는 모든 row 제거
data__.dropna(inplace=True)
# for col in columns:
#     # print(data__[col].shape)
#     print(data__[col].isnull().sum())

# 제거하고 남은 row
print('\nnumber of remained rows: {}'.format(len(data__)))

# 최소 연봉 지정
data__ = data__[data__.ConvertedSalary >= 18000.0]

# 연봉 순으로 정렬
data__.sort_values(by=['ConvertedSalary'], inplace=True)
data__.reset_index(inplace=True, drop=True)
print(data__.head())

# 고연봉 True / False : 기준 50000달러
bigger50000 = []
for sal in data__['ConvertedSalary']:
    if sal >= 50000:
        bigger50000.append(True)
    else:
        bigger50000.append(False)

print(bigger50000.count(True))
print(bigger50000.count(False))

data__['HighSalary'] = bigger50000
print(data__['HighSalary'])

# 가장 많은 샐러리를 받는 개발자
print('\nFeatures of the highest-paid person:')
print(data__.iloc[-1])

# 가장 적은 샐러리를 받는 개발자
print('\nFeatures of the the least paid person:')
print(data__.iloc[0])

# # 남은 feature의 nan 조사
# for col in columns:
#     print('Feature {} has {} nan'.format(col, data__[col].isnull().sum()))

# 남은 feature의 unique 조사
print('\nDifferent values of each column has:')
for col in columns:
    print('Feature {} has {}'.format(col, len(data__[col].unique())))

# # Save plot
# for col in columns:
#     labels = [lab for lab in data__[col].unique()]
#     plt.figure(figsize=(60, 10))
#     ax = pd.value_counts(data__[col]).plot.bar()
#     ax.tick_params(axis='x', labelrotation=10)
#     plt.savefig('/Users/leenamjun/ML-SuccessAsDeveloper/Project/Screenshots/' + col + '.png')

# Split train, target
data__.drop(['ConvertedSalary'], axis=1)
target = data__['HighSalary']
train = data__.drop(['HighSalary'], axis=1)

# Input example
aPerson = [(
    'No',
    'Yes',
    'Computer science, computer engineering, or software engineering',
    'JavaScript;HTML;CSS',
    'Slightly satisfied',
    '3-5 years',
    'MacOS',
    'Male',
    'Between 7:01 - 8:00 AM',
    'Linux;Mac OS;Windows Desktop or Server',
    'Node.js;React;Spring',
    '2',
    'MongoDB;SQL Server;PostgreSQL;Google Cloud Storage',
    'Daily or almost daily',
    'I have never participated in Q&A on Stack Overflow',
    'Once a day'
)]
train.append(aPerson)

# Salary 제외 하고 전부 categorical
# Encoding
encoders =[]
for label in train.columns.values:
    encoder = LabelEncoder()
    encoder.fit(train[label])
    encoders.append(encoder)
    train[label] = encoder.transform(train[label])

input_ex = train.iloc[-1]
train.drop([train.index[-1]])
print(input_ex)

# train test split
X_train, X_test, y_train, y_test = train_test_split(train, target, test_size=0.20)

# LogisticRegression
from sklearn.linear_model import LogisticRegression
# LRmodel = LogisticRegression()
# LRmodel.fit(X_train, y_train)
# dump(LRmodel, 'LRmodel.joblib')  # Save trained model as file # To load file: modelName= load('filename.joblib')
LRmodel = load('LRmodel.joblib')
# print(LRmodel.predict([np.array(input_ex)]))
predicted_LR = LRmodel.predict(X_test)

# KNN
from sklearn.neighbors import KNeighborsClassifier
KNmodel = KNeighborsClassifier()
KNmodel.fit(X_train, y_train)
dump(KNmodel, 'KNmodel.joblib')
# KNmodel = load('KNmodel.joblib')
predicted_KN = KNmodel.predict(X_test)

# SVM
# Decision tree
# Random forest
# gradientboostingclassifier
# xgbclassifier
# gaussiannb
# votingclassifier

# 모델 평가
from sklearn.metrics import classification_report
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score

print('Result of Logistic regression:')
print(classification_report(y_test, predicted_LR))
precision_score(y_test, predicted_LR, average=None)
recall_score(y_test, predicted_LR, average=None)

# TODO: 각 모델 해보기, 모델 평가, 모델 분석 