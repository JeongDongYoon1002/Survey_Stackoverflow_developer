import warnings
warnings.filterwarnings(action="ignore")
from sklearn.metrics import accuracy_score
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# read dataset
data=pd.read_csv("/Users/leenamjun/ML-SuccessAsDeveloper/Project/Data/survey_results_public.csv",encoding='latin1' )
#print(data.head())

# preprocessing & encoding
from sklearn.preprocessing import LabelEncoder
lbl = LabelEncoder()


index = 0;
for i in data['Salary']:
    i = str(i);
    for j in range(len(i)):
        if i[j] == ',':
            data['Salary'][index] = np.nan;
    index = index + 1;


data = data.dropna(how='all')
data = data.fillna(method='bfill')
data = data.fillna(method='ffill')

#print(data.isnull().sum())
y = data['Salary']
x = data.drop(['Salary'],axis=1)
data_columns = data.columns
for col in data.columns:
    data[col]=lbl.fit_transform(data[col])



# MinMax - Scaler
from sklearn.preprocessing import MinMaxScaler
sc = MinMaxScaler()
data = sc.fit_transform(data)

data = pd.DataFrame(data, columns = data_columns)

# show heatmap features correlation ranking

plt.figure(figsize=(8, 12))
heatmap = sns.heatmap(data.corr()[['Salary']].sort_values(by='Salary', ascending=False), vmin=-1, vmax=1, annot=True, cmap='BrBG')
heatmap.set_title('Features Correlating with Salary', fontdict={'fontsize':18}, pad=16);
plt.show()


data2 = pd.DataFrame(data, columns =['Salary','ConvertedSalary','SexualOrientation','Gender','AssessBenefits9','NumberMonitors',
'AdBlocker','JobEmailPriorities6','Methodology','CareerSatisfaction'])

corr = data2.corr();
y = data2['Salary']
y = pd.DataFrame({'Salary':y})
x = data2.drop(['Salary'],axis=1)