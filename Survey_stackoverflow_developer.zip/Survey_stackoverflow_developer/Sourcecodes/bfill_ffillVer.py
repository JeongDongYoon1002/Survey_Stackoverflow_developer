import pandas as pd # package for high-performance, easy-to-use data structures and data analysis
import numpy as np # fundamental package for scientific computing with Python
import warnings
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
warnings.filterwarnings("ignore")
from sklearn.model_selection import train_test_split
from joblib import dump, load
import sys
# Print all rows and columns
pd.set_option('display.float_format', '{:.2f}'.format) # 항상 float 형식으로
data = pd.read_csv("C:\\Users\\wjdeh\\Desktop\\survey_results_public.csv",encoding='latin1')

# 의미가 있어보이는 칼럼 뽑
data__ = data[['Hobby', 'OpenSource', 'UndergradMajor', 'LanguageWorkedWith', 'JobSatisfaction',
               'YearsCoding', 'OperatingSystem', 'Gender', 'WakeTime', 'PlatformWorkedWith',
               'FrameworkWorkedWith', 'NumberMonitors', 'DatabaseWorkedWith', 'StackOverflowVisit', 'StackOverflowParticipate',
               'CheckInCode', 'ConvertedSalary']]

columns = data__.columns.values



# 모든 값이 nan 값인 row 제거하고 bfill 먼저하고 다음에 ffill

data__ = data__.dropna(how='all')
data__ = data__.fillna(method='bfill')
data__ = data__.fillna(method='ffill')


# 제거하고 남은 row
print('\nnumber of remained rows: {}'.format(len(data__)))


# 최소 연봉 지정
data__ = data__[data__.ConvertedSalary >= 18000.0]

# 연봉 순으로 정렬
data__.sort_values(by=['ConvertedSalary'], inplace=True)
data__.reset_index(inplace=True, drop=True)
print(data__.head())

# 고연봉 True / False : 기준 50000달러
bigger50000 = []
for sal in data__['ConvertedSalary']:
    if sal >= 50000:
        bigger50000.append(True)
    else:
        bigger50000.append(False)

print(bigger50000.count(True))
print(bigger50000.count(False))

data__['HighSalary'] = bigger50000
print(data__['HighSalary'])

# 가장 많은 샐러리를 받는 개발자
print('\nFeatures of the highest-paid person:')
print(data__.iloc[-1])

# 가장 적은 샐러리를 받는 개발자
print('\nFeatures of the the least paid person:')
print(data__.iloc[0])

# # 남은 feature의 nan 조사
# for col in columns:
#     print('Feature {} has {} nan'.format(col, data__[col].isnull().sum()))

# 남은 feature의 unique 조사
print('\nDifferent values of each column has:')
for col in columns:
    print('Feature {} has {}'.format(col, len(data__[col].unique())))

# # Save plot
# for col in columns:
#     labels = [lab for lab in data__[col].unique()]
#     plt.figure(figsize=(60, 10))
#     ax = pd.value_counts(data__[col]).plot.bar()
#     ax.tick_params(axis='x', labelrotation=10)
#     plt.savefig('/Users/leenamjun/ML-SuccessAsDeveloper/Project/Screenshots/' + col + '.png')

# Split train, target
data__.drop(['ConvertedSalary'], axis=1)
target = data__['HighSalary']
train = data__.drop(['HighSalary'], axis=1)

# Input example
aPerson = [(
    'No',
    'Yes',
    'Computer science, computer engineering, or software engineering',
    'JavaScript;HTML;CSS',
    'Slightly satisfied',
    '3-5 years',
    'MacOS',
    'Male',
    'Between 7:01 - 8:00 AM',
    'Linux;Mac OS;Windows Desktop or Server',
    'Node.js;React;Spring',
    '2',
    'MongoDB;SQL Server;PostgreSQL;Google Cloud Storage',
    'Daily or almost daily',
    'I have never participated in Q&A on Stack Overflow',
    'Once a day'
)]
train.append(aPerson)

# Salary 제외 하고 전부 categorical
# Encoding
encoders =[]
for label in train.columns.values:
    encoder = LabelEncoder()
    encoder.fit(train[label])
    encoders.append(encoder)
    train[label] = encoder.transform(train[label])

input_ex = train.iloc[-1]
train.drop([train.index[-1]])
print(input_ex)

# train test split
X_train, X_test, y_train, y_test = train_test_split(train, target, test_size=0.20)

# LogisticRegression
from sklearn.linear_model import LogisticRegression
LRmodel = LogisticRegression()
LRmodel.fit(X_train, y_train)
dump(LRmodel, 'LRmodel.joblib')  # Save trained model as file # To load file: modelName= load('filename.joblib')
LRmodel = load('LRmodel.joblib')
print(LRmodel.predict([np.array(input_ex)]))
predicted_LR = LRmodel.predict(X_test)

# KNN
from sklearn.neighbors import KNeighborsClassifier
KNmodel = KNeighborsClassifier()
KNmodel.fit(X_train, y_train)
dump(KNmodel, 'KNmodel.joblib')
# KNmodel = load('KNmodel.joblib')
predicted_KN = KNmodel.predict(X_test)

# SVM
from sklearn.svm import SVC
svm_model = SVC()
svm_model.fit(X_train, y_train)
predicted_SVM = svm_model.predict(X_test)

# Decision tree
from sklearn.tree import DecisionTreeClassifier
TREEmodel = DecisionTreeClassifier()
TREEmodel.fit(X_train, y_train)
predicted_TREE = TREEmodel.predict(X_test)


# Random forest
from sklearn.ensemble import RandomForestClassifier
RANDOMmodel = RandomForestClassifier()
RANDOMmodel.fit(X_train, y_train)
predicted_RANDOM = RANDOMmodel.predict(X_test)

# gradientboostingclassifier
from sklearn.ensemble import GradientBoostingClassifier
GRADIENTmodel = GradientBoostingClassifier()
GRADIENTmodel.fit(X_train, y_train)
predicted_GRADIENT = GRADIENTmodel.predict(X_test)

# xgbclassifier
from xgboost import XGBClassifier
XGBCmodel = XGBClassifier()
XGBCmodel.fit(X_train, y_train)
predict_XGBC = XGBCmodel.predict(X_test)


# gaussiannb
from sklearn.naive_bayes import GaussianNB
GAUSSIANmodel = GaussianNB()
GAUSSIANmodel.fit(X_train, y_train)
predict_GAUSSIAN = GAUSSIANmodel.predict(X_test)

# votingclassifier
from sklearn.ensemble import VotingClassifier
VOTINGmodel = GaussianNB()
VOTINGmodel.fit(X_train, y_train)
predict_VOTING = VOTINGmodel.predict(X_test)

# 모델 평가
from sklearn.metrics import classification_report
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
print('-------------------------------------------------------------------------')
print('Result of Logistic regression:')
print("Train: {:.3f}".format(LRmodel.score(X_train, y_train)))
print("Test: {:.3f}".format(LRmodel.score(X_test, y_test)))  
print(classification_report(y_test, predicted_LR))
precision_score(y_test, predicted_LR, average=None)
recall_score(y_test, predicted_LR, average=None)
print('-------------------------------------------------------------------------')

print('Result of KNN:')
print("Train: {:.3f}".format(KNmodel.score(X_train, y_train)))
print("Test: {:.3f}".format(KNmodel.score(X_test, y_test)))  
print(classification_report(y_test, predicted_KN))
precision_score(y_test, predicted_KN, average=None)
recall_score(y_test, predicted_KN, average=None)
print('-------------------------------------------------------------------------')

print('Result of SVM:')
print("Train: {:.3f}".format(svm_model.score(X_train, y_train)))
print("Test: {:.3f}".format(svm_model.score(X_test, y_test)))  
print(classification_report(y_test, predicted_SVM))
precision_score(y_test, predicted_SVM, average=None)
recall_score(y_test, predicted_SVM, average=None)
print('-------------------------------------------------------------------------')

print('Result of DecisionTree:')
print("Train: {:.3f}".format(TREEmodel.score(X_train, y_train)))
print("Test: {:.3f}".format(TREEmodel.score(X_test, y_test))) 
print(classification_report(y_test, predicted_TREE))
precision_score(y_test, predicted_TREE, average=None)
recall_score(y_test, predicted_TREE, average=None)
print('-------------------------------------------------------------------------')

print('Result of RandomForestClassifier :')
print("Train: {:.3f}".format(RANDOMmodel.score(X_train, y_train)))
print("Test: {:.3f}".format(RANDOMmodel.score(X_test, y_test))) 
print(classification_report(y_test, predicted_RANDOM))
precision_score(y_test, predicted_RANDOM, average=None)
recall_score(y_test, predicted_RANDOM, average=None)
print('-------------------------------------------------------------------------')

print('Result of GradientBoostingClassifier :')
print("Train: {:.3f}".format(GRADIENTmodel.score(X_train, y_train)))
print("Test: {:.3f}".format(GRADIENTmodel.score(X_test, y_test))) 
print(classification_report(y_test, predicted_GRADIENT))
precision_score(y_test, predicted_GRADIENT, average=None)
recall_score(y_test, predicted_GRADIENT, average=None)
print('-------------------------------------------------------------------------')



print('Result of xgbclassifier :')
print("Train: {:.3f}".format(XGBCmodel.score(X_train, y_train)))
print("Test: {:.3f}".format(XGBCmodel.score(X_test, y_test))) 
print(classification_report(y_test, predict_XGBC))
precision_score(y_test, predict_XGBC , average=None)
recall_score(y_test, predict_XGBC , average=None)
print('-------------------------------------------------------------------------')


print('Result of GaussianNB :')
print("Train: {:.3f}".format(GAUSSIANmodel.score(X_train, y_train)))
print("Test: {:.3f}".format(GAUSSIANmodel.score(X_test, y_test))) 
print(classification_report(y_test, predict_GAUSSIAN))
precision_score(y_test, predict_GAUSSIAN , average=None)
recall_score(y_test, predict_GAUSSIAN , average=None)
print('-------------------------------------------------------------------------')

print('Result of Votingclassifier :')
print("Train: {:.3f}".format(VOTINGmodel.score(X_train, y_train)))
print("Test: {:.3f}".format(VOTINGmodel.score(X_test, y_test))) 
print(classification_report(y_test, predict_VOTING))
precision_score(y_test, predict_VOTING , average=None)
recall_score(y_test, predict_VOTING , average=None)
print('-------------------------------------------------------------------------')
# TODO: 각 모델 해보기, 모델 평가, 모델 분석 
