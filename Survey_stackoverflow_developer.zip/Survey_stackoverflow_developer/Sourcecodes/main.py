import pandas as pd # package for high-performance, easy-to-use data structures and data analysis
import numpy as np # fundamental package for scientific computing with Python
import warnings
import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")

# Print all rows and columns
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
data = pd.read_csv('/Users/leenamjun/ML-SuccessAsDeveloper/Project/Data/survey_results_public.csv')

# features information analysis
# print("Size of data", data.shape)
# print("Number of columns: ", len(data.columns.values))
# print(data.columns.values)
# print(data.isnull().sum())
# print(data.Gender)
# TODO null 개수
# TODO 로우, 칼럼의 갯수, 성별 피쳐로 봤을 때 남자가 몇명 여자가 몇명, 공부한 언어는 뭐뭐, 샐러리의 분포는 얼마부터 얼마 위와 같은 요소가 샐러리에 어떤 영향을 미칠까?
# One sentence description: How do developers live and work?

# 의미가 있어보이는 칼럼 뽑
data__ = data[['Hobby', 'OpenSource', 'UndergradMajor', 'LanguageWorkedWith', 'JobSatisfaction',
               'YearsCoding', 'OperatingSystem', 'Gender', 'WakeTime', 'PlatformWorkedWith',
               'FrameworkWorkedWith', 'NumberMonitors', 'DatabaseWorkedWith', 'StackOverflowVisit', 'StackOverflowParticipate',
               'CheckInCode', 'ConvertedSalary']]

columns = data__.columns.values
print(columns)

for col in columns:
    # print(data__[col].shape)
    print(data__[col].isnull().sum())

# salary 가 nan인 row 제거
data__.dropna(subset=['ConvertedSalary'], how='all', inplace=True)
for col in columns:
    # print(data__[col].shape)
    print(data__[col].isnull().sum())

data__.sort_values(by=['ConvertedSalary'])
print(data__.iloc[0])

# 남은 feature의 nan 조사
for col in columns:
    print('Feature {} has {} nan'.format(col, data__[col].isnull().sum()))

# # 남은 feature의 유니크 값 조사
# for col in columns:
#     print('Feature {} has {}'.format(col, data__[col].unique()))
#     pd.value_counts(data__[col]).plot.bar()
#     plt.savefig(col + '.png')

labels = [lab for lab in data__['UndergradMajor'].unique()]
plt.figure(figsize=(60, 10))
ax = pd.value_counts(data__['UndergradMajor']).plot.bar()
ax.tick_params(axis='x', labelrotation=10)
plt.savefig('fasdas.png')
