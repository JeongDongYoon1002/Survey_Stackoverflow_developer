import pandas as pd # package for high-performance, easy-to-use data structures and data analysis
import numpy as np # fundamental package for scientific computing with Python
import warnings
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
warnings.filterwarnings("ignore")
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from joblib import dump, load
import sys
# np.set_printoptions(threshold=sys.maxsize)
# pd.set_option('display.max_rows', 500)
# pd.set_option('display.max_columns', 500)
# pd.set_option('display.width', 1000)

# Print all rows and columns
pd.set_option('display.float_format', '{:.2f}'.format) # 항상 float 형식으로
data = pd.read_csv('/Users/leenamjun/ML-SuccessAsDeveloper/Project/Data/survey_results_public.csv')

# 의미가 있어보이는 칼럼 뽑
data__ = data[['Hobby', 'OpenSource', 'UndergradMajor', 'LanguageWorkedWith', 'JobSatisfaction',
               'YearsCoding', 'OperatingSystem', 'Gender', 'WakeTime', 'PlatformWorkedWith',
               'FrameworkWorkedWith', 'NumberMonitors', 'DatabaseWorkedWith', 'StackOverflowVisit', 'StackOverflowParticipate',
               'CheckInCode', 'ConvertedSalary']]

# 하나라도 nan이 있는 모든 row 제거
data__.dropna(inplace=True)
# for col in columns:
#     # print(data__[col].shape)
#     print(data__[col].isnull().sum())

# 제거하고 남은 row
print('\nnumber of remained rows: {}'.format(len(data__)))

# 최소 연봉 지정
data__ = data__[data__.ConvertedSalary >= 18000.0]
print(len(data__))

bigger50000 = []
for sal in data__['ConvertedSalary']:
    if sal >= 50000:
        bigger50000.append(True)
    else:
        bigger50000.append(False)

print(bigger50000.count(True))
print(bigger50000.count(False))

data__['HighSalary'] = bigger50000
print(data__['HighSalary'])